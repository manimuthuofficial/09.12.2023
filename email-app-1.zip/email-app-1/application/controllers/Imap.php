<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmailControllers extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
	{
		// Connect to the IMAP mailbox
		$mailbox = imap_open('{mail.mdsengg.com:993/ssl}', 'protrack@mdsengg.com', 'Protrack');

		// Check if the connection was successful
		if (!$mailbox) {
			$error = imap_last_error();
			echo "Connection failed: $error";
		} else {
			// Connection successful message
			//echo "Connected.";

			// Search for undeleted emails in the INBOX
			$emails = imap_search($mailbox, 'UNDELETED');

			if ($emails) {
				// Array to store email data
				$email_data = array();

				// Loop through each email
				foreach ($emails as $email_id) {
					// Get email headers, body, and structure
					$header = imap_headerinfo($mailbox, $email_id);
					$structure = imap_fetchstructure($mailbox, $email_id);
					$body = "";
					$has_attachments = false;

					// Extract To, CC, and BCC addresses
					$to_addresses = array();
					foreach ($header->to as $address) {
						$to_addresses[] = $address->mailbox . "@" . $address->host;
					}

					$cc_addresses = array();
					foreach ($header->cc as $address) {
						$cc_addresses[] = $address->mailbox . "@" . $address->host;
					}

					$bcc_addresses = array();
					foreach ($header->bcc as $address) {
						$bcc_addresses[] = $address->mailbox . "@" . $address->host;
					}

					// Check for attachments
					if (isset($structure->parts)) {
						for ($i = 1; $i < count($structure->parts); $i++) {
							if ($structure->parts[$i]->disposition === "attachment") {
								$has_attachments = true;
								break;
							}
						}
					}

					// Extract message body based on content type
					if ($structure->parts) {
						$body = imap_fetchbody($mailbox, $email_id, "1");
					} else {
						$body = imap_body($mailbox, $email_id);
					}

					// Store email information in an array
					$email_data[] = array(
						'id' => $email_id,
						'from' => $header->from[0]->mailbox . "@" . $header->from[0]->host,
						'to' => implode(", ", $to_addresses),
						'cc' => implode(", ", $cc_addresses),
						'bcc' => implode(", ", $bcc_addresses),
						'subject' => $header->subject,
						'date' => $header->date,
						'body' => $body,
						'attachments' => ($has_attachments ? "Yes" : "No"),
					);
				}

				// Close the connection
				imap_close($mailbox);

				// Load the view and pass data
				$this->load->view('index', array('email_data' => $email_data));
			} else {
				// No undeleted emails found message
				echo "No undeleted emails found.";

				// Close the connection
				imap_close($mailbox);
			}
		}
	}
	
	
	public function viewEmail($id)
	{
		// Connect to the IMAP mailbox
		$mailbox = imap_open('{mail.mdsengg.com:993/ssl}', 'protrack@mdsengg.com', 'Protrack');

		// Check if the connection was successful
		if (!$mailbox) {
			$error = imap_last_error();
			echo "Connection failed: $error";
		} else {
			// Get details of the specific email using $id
			$header = imap_headerinfo($mailbox, $id);
			$structure = imap_fetchstructure($mailbox, $id);
			$body = "";
			$has_attachments = false;

			// Extract To, CC, and BCC addresses
			$to_addresses = array();
			foreach ($header->to as $address) {
				$to_addresses[] = $address->mailbox . "@" . $address->host;
			}

			$cc_addresses = array();
			foreach ($header->cc as $address) {
				$cc_addresses[] = $address->mailbox . "@" . $address->host;
			}

			$bcc_addresses = array();
			foreach ($header->bcc as $address) {
				$bcc_addresses[] = $address->mailbox . "@" . $address->host;
			}

			// Check for attachments
			if (isset($structure->parts)) {
				for ($i = 1; $i < count($structure->parts); $i++) {
					if ($structure->parts[$i]->disposition === "attachment") {
						$has_attachments = true;
						break;
					}
				}
			}

			// Extract message body based on content type
			if ($structure->parts) {
				$body = imap_fetchbody($mailbox, $id, "1");
			} else {
				$body = imap_body($mailbox, $id);
			}

			// Store email information in an array
			$email_data = array(
				'id' => $id,
				'from' => $header->from[0]->mailbox . "@" . $header->from[0]->host,
				'to' => implode(", ", $to_addresses),
				'cc' => implode(", ", $cc_addresses),
				'bcc' => implode(", ", $bcc_addresses),
				'subject' => $header->subject,
				'date' => $header->date,
				'body' => $body,
				'attachments' => ($has_attachments ? "Yes" : "No"),
			);

			// Close the connection
			imap_close($mailbox);

			// Load the view and pass data
			$this->load->view('view-email', array('email_data' => $email_data));
		}
	}
	
	
	
	public function downloadAttachment($id, $filename)
	{
		// Connect to the IMAP mailbox
		$mailbox = imap_open('{mail.mdsengg.com:993/ssl}', 'protrack@mdsengg.com', 'Protrack');

		// Check if the connection was successful
		if (!$mailbox) {
			$error = imap_last_error();
			echo "Connection failed: $error";
		} else {
			// Get the attachment content
			$attachment = imap_fetchbody($mailbox, $id, $filename);

			// Send the appropriate headers for file download
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . $filename . '"');
			header('Content-Length: ' . strlen($attachment));

			// Output the attachment content
			echo $attachment;

			// Close the connection
			imap_close($mailbox);
		}
	}


	
}
