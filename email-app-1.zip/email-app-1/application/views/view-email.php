<!DOCTYPE html>
<html lang="en">
<head>
<title>Bootstrap 4 Example</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


</head>
<body>

	<div class="container">
		<h1 style="font-weight:600;margin-top:30px;margin-bottom:30px">MAIL VIEW</h1>
		<hr>
		
		<div>
            <p>ID: <?= $email_data['id'] ?></p>
            <p>From: <?= $email_data['from'] ?></p>
            <p>To: <?= $email_data['to'] ?></p>
            <p>CC: <?= $email_data['cc'] ?></p>
            <p>BCC: <?= $email_data['bcc'] ?></p>
            <p>Subject: <?= $email_data['subject'] ?></p>
            <p>Date: <?= $email_data['date'] ?></p>
			
			
			
            <p>Body: <?= $email_data['body'] ?></p>
			
			
			
			
			
			
            <p>Attachments: <?= $email_data['attachments'] ?></p>
			
			<!-- Display attachments if available -->
			<?php if ($email_data['attachments'] === 'Yes'): ?>
				<div>
					<h6><b>ATTACHMENTS:</b></h6>
					<?php
					// Connect to the IMAP mailbox again
					$mailbox = imap_open('{mail.mdsengg.com:993/ssl}', 'protrack@mdsengg.com', 'Protrack');

					// Check if the connection was successful
					if (!$mailbox) {
						$error = imap_last_error();
						echo "Connection failed: $error";
					} else {
						// Get the structure of the email
						$structure = imap_fetchstructure($mailbox, $email_data['id']);

						// Check if the email has parts
						if (isset($structure->parts)) {
							// Loop through each part
							foreach ($structure->parts as $part) {
								// Check if part has an attachment disposition
								if ($part->disposition === 'attachment') {
									// Get the attachment filename
									$filename = $part->dparameters[0]->value;

									// Display the link to download the attachment
									echo '<p><a href="' . base_url('emailcontrollers/downloadAttachment/' . $email_data['id'] . '/' . $filename) . '">' . $filename . '</a></p>';
								}
							}
						}

						// Close the connection
						imap_close($mailbox);
					}
					?>
				</div>
			<?php endif; ?>
			
			
            <hr>
        </div>
		
	</div>

</body>
</html>

<style>
body
{
	font-family: 'Arial', sans-serif;
}
</style>