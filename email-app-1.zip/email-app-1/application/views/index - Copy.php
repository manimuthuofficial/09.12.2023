<!DOCTYPE html>
<html lang="en">
<head>
<title>Bootstrap 4 Example</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


</head>
<body>

	<div class="container">
		<h1 style="font-weight:600;margin-top:30px;margin-bottom:30px">MAIL INBOX</h1>
		<hr>
		 <?php foreach ($email_data as $email): ?>
		
		<div>
            <p>ID: <?= $email['id'] ?></p>
            <p>From: <?= $email['from'] ?></p>
            <p>To: <?= $email['to'] ?></p>
            <p>CC: <?= $email['cc'] ?></p>
            <p>BCC: <?= $email['bcc'] ?></p>
            <p>Subject: <?= $email['subject'] ?></p>
            <p>Date: <?= $email['date'] ?></p>
            <p>Body: <?= $email['body'] ?></p>
            <p>Attachments: <?= $email['attachments']; ?></p>
			<!-- Add a link to view the detailed email -->
            <p><a href="<?= base_url('EmailControllers/viewEmail/' . $email['id']) ?>">View Email</a></p>

            <hr>
        </div>
		
		 <?php endforeach; ?>
		
	</div>

</body>
</html>

<style>
body
{
	font-family: 'Arial', sans-serif;
}
</style>